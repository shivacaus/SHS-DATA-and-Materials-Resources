Notepad++ v8.6.6 bug-fixes & new enhancements:

# Journal Article Template

## Introduction
This repository contains a LaTeX template for submitting articles to [Nepal Journal of Mathematical Sciences (NJMS)]. 
It follows the journal's formatting guidelines and requirements specified by the journal.

## File Structure
- `main.tex` [NJMS-TEMPLATE.tex]- The main LaTeX document.
- `references.bib` [NJMSBIB.bib]- Bibliography file.
- `figures/` - Folder for storing figures. (permanently contains NJMS logobw1.png)
- 'PDF' [NJMS-TEMPLATE.pdf]- The compiled PDF generated from LaTeX.
-  Other necessary auxiliary files: .aux, .bbl, .dvi, .gz, etc
- `README.md` - This documentation.

## Requirements
To use this template, install:
- **TeX Live / MikTeX / Overleaf**
- **BibTeX** for bibliography management (If applicable)
- **LaTeX editor** (TeXstudio, TeXworks, TeXmaker, or Overleaf)

## How to Use 
1. Open `main.tex`
   # READ CAREFULLY THE USER MANUAL AND WHOLE LATEX FILE.
    and modify the contents/sections accordingly. 
2. Add your references to `references.bib`. (If you are not using BibTeX database, enter your references manually in main tex  with \bibitem.)
3. Include figures in the `figures/` directory.
4. Compile the Document: 
   i) If using Overleaf: Simply upload and compile.
  ii) If using local TeX distribution, Compile using: (If you do not use BibTeX database, Compile directly.)
   pdflatex main.tex
   bibtex main
   pdflatex main.tex
   pdflatex main.tex
## Template Features
Predefined: Headings(edotor section), First page (author and editor section), Abstract/keywords(author section), 
            Sections: Introduction to conclusions followed by References, Akknowledgement (author section)
			Subsections/subsubsections(author section), End mark.

Automatic numbering of figures, tables, and equations.

BibTeX bibliography support.(If applicable)

Compatibility with Overleaf for cloud-based editing.

## Troubleshooting
Missing references? Run bibtex main before recompiling. ( If BibTeX citations are used)

Images not appearing? Ensure they are in the correct format (PNG, JPG, PDF).

Compilation errors? Check for missing packages in the LaTeX log.

## License
This template is provided under [School of Mathematical SciencesTribhuvan University, Kirtipur Kathmandu, Nepal. 
  Website:www.sms.tu.edu.np, Email:njmseditor@gmail.com]
 and can be used freely for academic and research purposes.

## Contact
For any issues or suggestions, please contact [NJMS Editor] at [njmseditor@gmail.com] or open an issue in the repository. 

